// assets/app.js
let ACTIVE = null;      // active chat user id
let LAST_ID = 0;        // last message id seen
let POLLER = null;

const elUsers = document.getElementById('users');
const elSearch = document.getElementById('search');
const elMessages = document.getElementById('messages');
const elChatWith = document.getElementById('chat-with');
const elForm = document.getElementById('send-form');
const elInput = document.getElementById('msg-input');
const elSend = document.getElementById('send-btn');

function esc(s) {
  const div = document.createElement('div');
  div.innerText = s;
  return div.innerHTML;
}

async function loadUsers(q = '') {
  const res = await fetch('users.php?q=' + encodeURIComponent(q));
  const users = await res.json();
  elUsers.innerHTML = users.map(u => `
    <div class="user ${ACTIVE === u.id ? 'active' : ''}" data-id="${u.id}">
      <div class="avatar">${esc(u.username[0].toUpperCase())}</div>
      <div class="uname">${esc(u.username)}</div>
    </div>
  `).join('') || '<div class="muted">No users yet.</div>';

  [...elUsers.querySelectorAll('.user')].forEach(node => {
    node.onclick = () => openChat(parseInt(node.dataset.id, 10));
  });
}

async function openChat(userId) {
  ACTIVE = userId;
  LAST_ID = 0;
  elMessages.innerHTML = '';
  elInput.disabled = false;
  elSend.disabled = false;
  await fetchNew(); // also sets header
  startPolling();
}

function startPolling() {
  if (POLLER) clearInterval(POLLER);
  POLLER = setInterval(fetchNew, 1500);
}

async function fetchNew() {
  if (!ACTIVE) return;
  try {
    const url = fetch_messages.php?user_id=${ACTIVE}&last_id=${LAST_ID};
    const res = await fetch(url);
    const data = await res.json();
    if (data.other_username) {
      elChatWith.textContent = Chat with ${data.other_username};
    }
    if (Array.isArray(data.messages) && data.messages.length) {
      const frag = document.createDocumentFragment();
      data.messages.forEach(m => {
        const row = document.createElement('div');
        row.className = 'msg ' + (m.from_me ? 'me' : 'them');
        row.innerHTML = `
          <div class="bubble">${esc(m.body)}</div>
          <div class="meta">${esc(m.created_at)}</div>
        `;
        frag.appendChild(row);
      });
      elMessages.appendChild(frag);
      LAST_ID = data.last_id || LAST_ID;
      elMessages.scrollTop = elMessages.scrollHeight;
    }
  } catch (e) {
    console.error(e);
  }
}

elForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!ACTIVE) return;
  const body = elInput.value.trim();
  if (!body) return;
  elInput.value = '';
  try {
    const form = new FormData();
    form.append('to', String(ACTIVE));
    form.append('body', body);
    const res = await fetch('send_message.php', { method: 'POST', body: form });
    const data = await res.json();
    if (data.ok) {
      // Immediately render my own message for snappy feel
      const row = document.createElement('div');
      row.className = 'msg me';
      row.innerHTML = <div class="bubble">${esc(body)}</div><div class="meta">${esc(data.created_at)}</div>;
      elMessages.appendChild(row);
      elMessages.scrollTop = elMessages.scrollHeight;
    }
  } catch (e) {
    console.error(e);
  }
});

elSearch.addEventListener('input', (e) => {
  loadUsers(e.target.value);
});

// init
loadUsers();
